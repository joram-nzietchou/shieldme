// lib/widgets/shield_button.dart
import 'package:flutter/material.dart';
import '../themes/app_theme.dart';

class ShieldButton extends StatelessWidget {
  final String   label;
  final bool     loading;
  final VoidCallback? onPressed;
  final Color?   color;

  const ShieldButton({
    super.key,
    required this.label,
    this.loading  = false,
    this.onPressed,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 52,
      child: ElevatedButton(
        onPressed: loading ? null : onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: color ?? AppColors.blue,
          foregroundColor: Colors.white,
          disabledBackgroundColor: (color ?? AppColors.blue).withOpacity(0.6),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          elevation: 0,
        ),
        child: loading
            ? const SizedBox(
                width: 22,
                height: 22,
                child: CircularProgressIndicator(
                  color: Colors.white,
                  strokeWidth: 2.5,
                ),
              )
            : Text(
                label,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
      ),
    );
  }
}