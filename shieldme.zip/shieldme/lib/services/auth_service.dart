// lib/services/auth_service.dart
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class AuthService {
  static const _baseUrl = 'http://localhost:3000/api'; // Changer pour prod
  static const _accessKey  = 'access_token';
  static const _refreshKey = 'refresh_token';

  // ── Register (étape 1 : envoie OTP)
  static Future<Map<String, dynamic>> register({
    required String name,
    required String phone,
  }) async {
    final res = await http.post(
      Uri.parse('$_baseUrl/auth/register'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'name': name, 'phone': phone}),
    );
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  // ── Verify OTP (étape 2 : vérifie code + reçoit tokens)
  static Future<Map<String, dynamic>> verifyOtp({
    required String phone,
    required String code,
  }) async {
    final res = await http.post(
      Uri.parse('$_baseUrl/auth/verify-otp'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'phone': phone, 'code': code}),
    );
    final data = jsonDecode(res.body) as Map<String, dynamic>;
    if (res.statusCode == 200) {
      await _saveTokens(
        access:  data['access_token'],
        refresh: data['refresh_token'],
      );
    }
    return data;
  }

  // ── Login (envoie OTP à l'utilisateur existant)
  static Future<Map<String, dynamic>> login({required String phone}) async {
    final res = await http.post(
      Uri.parse('$_baseUrl/auth/login'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'phone': phone}),
    );
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  // ── Refresh access token
  static Future<bool> refreshToken() async {
    final prefs = await SharedPreferences.getInstance();
    final refreshToken = prefs.getString(_refreshKey);
    if (refreshToken == null) return false;

    final res = await http.post(
      Uri.parse('$_baseUrl/auth/refresh'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'refresh_token': refreshToken}),
    );

    if (res.statusCode == 200) {
      final data = jsonDecode(res.body);
      await prefs.setString(_accessKey, data['access_token']);
      return true;
    }
    return false;
  }

  // ── Logout
  static Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    final accessToken  = prefs.getString(_accessKey);
    final refreshToken = prefs.getString(_refreshKey);

    if (accessToken != null) {
      await http.post(
        Uri.parse('$_baseUrl/auth/logout'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $accessToken',
        },
        body: jsonEncode({'refresh_token': refreshToken}),
      );
    }

    await prefs.remove(_accessKey);
    await prefs.remove(_refreshKey);
  }

  // ── Vérifier si l'utilisateur est connecté
  static Future<bool> isLoggedIn() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.containsKey(_accessKey);
  }

  // ── Sauvegarder les tokens
  static Future<void> _saveTokens({
    required String access,
    required String refresh,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_accessKey, access);
    await prefs.setString(_refreshKey, refresh);
  }

  // ── Récupérer l'access token
  static Future<String?> getAccessToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_accessKey);
  }
}