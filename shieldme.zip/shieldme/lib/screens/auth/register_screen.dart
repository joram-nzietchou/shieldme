// lib/screens/auth/register_screen.dart
import 'package:flutter/material.dart';
import '../../themes/app_theme.dart';
import '../../services/auth_service.dart';
import '../../widgets/auth_header.dart';
import '../../widgets/shield_button.dart';
import 'otp_screen.dart';
import 'login_screen.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _nameCtrl  = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _formKey   = GlobalKey<FormState>();
  bool _loading    = false;

  @override
  void dispose() {
    _nameCtrl.dispose();
    _phoneCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);

    try {
      final result = await AuthService.register(
        name:  _nameCtrl.text.trim(),
        phone: _phoneCtrl.text.trim(),
      );

      if (!mounted) return;

      if (result.containsKey('access_token') == false &&
          result.containsKey('message')) {
        // Succès → aller à l'écran OTP
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => OtpScreen(
              phone:    _phoneCtrl.text.trim(),
              name:     _nameCtrl.text.trim(),
              isLogin:  false,
            ),
          ),
        );
      } else {
        _showError(result['message'] ?? 'Une erreur est survenue.');
      }
    } catch (e) {
      _showError('Impossible de se connecter au serveur.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _showError(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: AppColors.red,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final dim = Theme.of(context).brightness == Brightness.dark
        ? AppColors.dimDark
        : AppColors.dimLight;

    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            // ── En-tête
            AuthHeader(
              icon: '🛡️',
              title: 'Créer un compte',
              subtitle: 'Protégez votre argent MoMo dès aujourd\'hui',
            ),

            // ── Formulaire
            Padding(
              padding: const EdgeInsets.all(24),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Nom complet
                    _label('Nom complet'),
                    const SizedBox(height: 8),
                    TextFormField(
                      controller: _nameCtrl,
                      textCapitalization: TextCapitalization.words,
                      decoration: const InputDecoration(
                        hintText: 'Jean Kamga',
                        prefixIcon: Icon(Icons.person_outline),
                      ),
                      validator: (v) =>
                          (v == null || v.trim().isEmpty) ? 'Entrez votre nom' : null,
                    ),

                    const SizedBox(height: 20),

                    // Téléphone
                    _label('Numéro de téléphone'),
                    const SizedBox(height: 8),
                    TextFormField(
                      controller: _phoneCtrl,
                      keyboardType: TextInputType.phone,
                      decoration: const InputDecoration(
                        hintText: '+237 6XX XXX XXX',
                        prefixIcon: Icon(Icons.phone_outlined),
                      ),
                      validator: (v) {
                        if (v == null || v.trim().isEmpty) return 'Entrez votre numéro';
                        if (v.trim().length < 9) return 'Numéro invalide';
                        return null;
                      },
                    ),

                    const SizedBox(height: 28),

                    // Bouton
                    ShieldButton(
                      label: 'Recevoir le code OTP',
                      loading: _loading,
                      onPressed: _submit,
                    ),

                    const SizedBox(height: 20),

                    // Lien connexion
                    Center(
                      child: GestureDetector(
                        onTap: () => Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(builder: (_) => const LoginScreen()),
                        ),
                        child: RichText(
                          text: TextSpan(
                            style: TextStyle(color: dim, fontSize: 14),
                            children: [
                              const TextSpan(text: 'Déjà un compte ? '),
                              TextSpan(
                                text: 'Se connecter',
                                style: const TextStyle(
                                  color: AppColors.blue,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _label(String text) => Text(
        text,
        style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
      );
}