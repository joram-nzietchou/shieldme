// lib/screens/auth/login_screen.dart
import 'package:flutter/material.dart';
import '../../themes/app_theme.dart';
import '../../services/auth_service.dart';
import '../../widgets/auth_header.dart';
import '../../widgets/shield_button.dart';
import 'otp_screen.dart';
import 'register_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _phoneCtrl = TextEditingController();
  final _formKey   = GlobalKey<FormState>();
  bool  _loading   = false;

  @override
  void dispose() {
    _phoneCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);

    try {
      final result = await AuthService.login(phone: _phoneCtrl.text.trim());

      if (!mounted) return;

      // Si la réponse contient un message et pas d'erreur HTTP → succès
      if (result.containsKey('message') && !result.containsKey('error')) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => OtpScreen(
              phone:   _phoneCtrl.text.trim(),
              name:    '',
              isLogin: true,
            ),
          ),
        );
      } else {
        _showError(result['message'] ?? 'Erreur lors de la connexion.');
      }
    } catch (e) {
      _showError('Impossible de se connecter au serveur.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _showError(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: AppColors.red,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final dim = Theme.of(context).brightness == Brightness.dark
        ? AppColors.dimDark
        : AppColors.dimLight;

    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            AuthHeader(
              icon: '👋',
              title: 'Bon retour!',
              subtitle: 'Entrez votre numéro pour recevoir un code',
            ),

            Padding(
              padding: const EdgeInsets.all(24),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Numéro de téléphone',
                      style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
                    ),
                    const SizedBox(height: 8),
                    TextFormField(
                      controller: _phoneCtrl,
                      keyboardType: TextInputType.phone,
                      decoration: const InputDecoration(
                        hintText: '+237 6XX XXX XXX',
                        prefixIcon: Icon(Icons.phone_outlined),
                      ),
                      validator: (v) {
                        if (v == null || v.trim().isEmpty) return 'Entrez votre numéro';
                        if (v.trim().length < 9) return 'Numéro invalide';
                        return null;
                      },
                    ),

                    const SizedBox(height: 28),

                    ShieldButton(
                      label: 'Recevoir le code OTP',
                      loading: _loading,
                      onPressed: _submit,
                    ),

                    const SizedBox(height: 20),

                    Center(
                      child: GestureDetector(
                        onTap: () => Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(builder: (_) => const RegisterScreen()),
                        ),
                        child: RichText(
                          text: TextSpan(
                            style: TextStyle(color: dim, fontSize: 14),
                            children: [
                              const TextSpan(text: 'Pas encore de compte ? '),
                              const TextSpan(
                                text: "S'inscrire",
                                style: TextStyle(
                                  color: AppColors.blue,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}