// lib/main.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'themes/app_theme.dart';
import 'services/auth_service.dart';
import 'screens/auth/register_screen.dart';
import 'screens/auth/login_screen.dart';
import 'screens/auth/otp_screen.dart';
import 'screens/splash_screen.dart';
import 'screens/home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Forcer orientation portrait
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  // Couleur de la status bar
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
  ));

  runApp(const ShieldMeApp());
}

class ShieldMeApp extends StatelessWidget {
  const ShieldMeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ShieldMe',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      darkTheme: AppTheme.dark,
      themeMode: ThemeMode.system,
      home: const SplashScreen(),
      routes: {
        '/splash':    (_) => const SplashScreen(),
        '/register':  (_) => const RegisterScreen(),
        '/login':     (_) => const LoginScreen(),
        '/home':      (_) => const HomeScreen(),
      },
      onGenerateRoute: (settings) {
        // Route dynamique pour OTP (nécessite des arguments)
        if (settings.name == '/otp') {
          final args = settings.arguments as Map<String, dynamic>;
          return MaterialPageRoute(
            builder: (_) => OtpScreen(
              phone:   args['phone'],
              name:    args['name'] ?? '',
              isLogin: args['isLogin'] ?? false,
            ),
          );
        }
        return null;
      },
    );
  }
}
