// lib/theme/app_theme.dart
import 'package:flutter/material.dart';

class AppColors {
  // Brand colors (from shieldMe.html CSS variables)
  static const blue      = Color(0xFF1E3A5F);
  static const blueMid   = Color(0xFF2B5BA1);
  static const blueLight = Color(0xFF4A90D9);
  static const blueDim   = Color(0x141E3A5F);

  static const green     = Color(0xFF0EA371);
  static const greenDim  = Color(0x1A0EA371);
  static const red       = Color(0xFFE53E3E);
  static const orange    = Color(0xFFDD6B20);

  // Light theme
  static const bgLight      = Color(0xFFF0F4FF);
  static const surfaceLight = Color(0xFFFFFFFF);
  static const borderLight  = Color(0xFFE2E8F5);
  static const textLight    = Color(0xFF1A202C);
  static const dimLight     = Color(0xFF718096);

  // Dark theme
  static const bgDark      = Color(0xFF0A0F1E);
  static const surfaceDark = Color(0xFF111827);
  static const borderDark  = Color(0xFF1E2D4A);
  static const textDark    = Color(0xFFEDF2FF);
  static const dimDark     = Color(0xFF8899BB);
}

class AppTheme {
  static ThemeData get light => ThemeData(
    useMaterial3: true,
    brightness: Brightness.light,
    scaffoldBackgroundColor: AppColors.bgLight,
    colorScheme: const ColorScheme.light(
      primary:   AppColors.blue,
      secondary: AppColors.blueLight,
      surface:   AppColors.surfaceLight,
      error:     AppColors.red,
    ),
    fontFamily: 'PlusJakartaSans',
    inputDecorationTheme: _inputTheme(AppColors.borderLight, AppColors.textLight),
    elevatedButtonTheme: _buttonTheme(),
  );

  static ThemeData get dark => ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: AppColors.bgDark,
    colorScheme: const ColorScheme.dark(
      primary:   AppColors.blueLight,
      secondary: AppColors.blueLight,
      surface:   AppColors.surfaceDark,
      error:     AppColors.red,
    ),
    fontFamily: 'PlusJakartaSans',
    inputDecorationTheme: _inputTheme(AppColors.borderDark, AppColors.textDark),
    elevatedButtonTheme: _buttonTheme(),
  );

  static InputDecorationTheme _inputTheme(Color border, Color text) =>
      InputDecorationTheme(
        filled: true,
        fillColor: Colors.transparent,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AppColors.blue, width: 2),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AppColors.red),
        ),
      );

  static ElevatedButtonThemeData _buttonTheme() => ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.blue,
          foregroundColor: Colors.white,
          minimumSize: const Size(double.infinity, 52),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
          elevation: 0,
        ),
      );
}